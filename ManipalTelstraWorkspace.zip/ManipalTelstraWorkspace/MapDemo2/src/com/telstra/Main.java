package com.telstra;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Product store map maintained for holding name and price
		
		Map<String,Integer> hm = new HashMap<String, Integer>();
		hm.put("sofa", 5000);
		hm.put("table", 3000);
		hm.put("lamp", 2000);
		
		System.out.println(hm.keySet());
		System.out.println(hm.values());
		System.out.println(hm.entrySet());
		
		
		int totamt=0;
		for(String str:hm.keySet()) {
			totamt+=hm.get(str);
		}
		System.out.println("Investment: "+totamt);
		
		
		// Customer list , place they reside
		
		TreeMap<Customer,String> custMap = new TreeMap<Customer, String>();
		
		custMap.put(new Customer(500,"Lary"), "States");
		custMap.put(new Customer(500, "Lary"), "Jersey");
		custMap.put(new Customer(400,"Lary"), "Florida");
		custMap.put(new Customer(600,"Bary"), "NY");
		// search this
		
		for(Customer cust:custMap.keySet()) {
			System.out.println(cust.getName()+"  "+custMap.get(cust));
		}
	}

}
