package com.telstra.pack1;

import java.util.List;

public class Test {

	// is find the sum of all elements in given list
	// what type of list : UpperBound : Numbers(Integer/Double/Byte/Long/Short)
	
	public static Number sumOfList(List<? extends Number> nlist) {
		
		double s = 0.0;
		for(Number n:nlist) {
			s+=n.doubleValue();
		}
		return s;
	}
	
	// LowerBound example :
	
	public static Number sumOfList1(List<? super Integer> llist) {
		
		double s = 0.0;
		for(Object n:llist) {
			s+=((Integer)n).intValue();
		}
		return s;
	}
	
	// Unbounded examples works with object classes
	
	public static Number printList(List<?> list) {
		for(Object ele:list) {
			System.out.print(ele+"  ");
		}
		System.out.println();
		return list.size();
	}
	
	// <T extends Comparable<T>> means that <T> is having upper bound of Comparable<T> objects
	//all wrapper classes and under defined class which implements Comparable<T> can be
	// passed and returned
	public static <T extends Comparable<T>>  T maximum(T x,T y,T z) {
		
		T max = x;
		if(y.compareTo(max)>0)
			max=y;
		
		if(z.compareTo(max)>0)
			max=z;
		
		return max;
	}

}
