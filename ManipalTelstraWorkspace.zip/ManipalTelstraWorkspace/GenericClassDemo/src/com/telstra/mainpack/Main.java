package com.telstra.mainpack;

import com.telstra.pack1.test;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		test<String,String> ob1 = new test<String, String>();
		ob1.setOb1("Good");
		ob1.setOb2("Evening");
		
		System.out.println(ob1);
		
		test<Integer,String> ob2 = new test<Integer, String>(10,"Amex");
		
		System.out.println(ob2.getOb2());
		System.out.println(ob2);
	}

}
