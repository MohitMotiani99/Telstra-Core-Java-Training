package com.telstra.orgpack;

import com.telstra.emppack.Employee;
import com.telstra.emppack.Manager;
import com.telstra.emppack.Programmer;

public class OrgMain {

	public static void main(String[] args) {
		
		
		
		Manager m1=new Manager(200,"Harish",60000,"Finance",5);
		System.out.println(m1.getDetails()+"  "+m1.calcNetSal());
		
		Programmer p1=new Programmer(300,"Man",50000,3,"Java");
		System.out.println(p1.getDetails()+"  "+p1.calcNetSal());
		
		//giving a base class reference to derived class object
		
//		Employee e=new Manager(201,"Ravish",65000,"HR",7);
//		System.out.println(e.getDetails());
//		
//		// downcasting
//		Manager m=(Manager)e;
//		System.out.println(m.getDeptname());
//		System.out.println(m.getEmpCount());
//		System.out.println(m.getDetails());
//		
//		System.out.println();
//		
		// Employee Array
		// Heterogenous Array btu due to IS-A rel with base class
		Employee[] emparr=new Employee[4];
		emparr[0]=new Programmer(1,"Amex",30000,3,"JS");
		emparr[1]=new Manager(2,"Bob",40000,"Finance",5);
		emparr[2]=new Programmer(3,"Cat",50000,4,"Java");
		emparr[3]=new Manager(4,"Dax",60000,"HR",7);
		
		System.out.println("Printing the details of the employee");
		for(Employee emp:emparr)//e when declared here is still not in for scope ,for scope starts after the {
		{
			System.out.println(emp.getDetails());
			if(emp instanceof Programmer)
			{
				Programmer p=(Programmer)emp;
				System.out.println(p.calcNetSal());
			}
		}
		// Why emp.calcNetSal() not working with type casting???
		//
		//
		//
	}

}
