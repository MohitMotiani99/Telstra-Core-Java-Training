package com.telstra.emppack;

public class Programmer extends Employee {
	private int noOfprojects;
	private String skill;
	public Programmer(int empId, String empName, int bSal, int noOfprojects, String skill) {
		super(empId, empName, bSal);
		this.noOfprojects = noOfprojects;
		this.skill = skill;
	}
	
	
	public String getDetails() {
		return super.getDetails()+"  "+noOfprojects+"  "+skill;
	}


	public int getNoOfprojects() {
		return noOfprojects;
	}


	public String getSkill() {
		return skill;
	}


	@Override
	public double calcNetSal() {
		// TODO Auto-generated method stub
		return 1.1*bSal+0.1*noOfprojects;
		
	}
	
	
}
