package prgpack;


public class Counter {
	public int count;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	public int increment() {
		return ++count;
	}
	
	public int decrement() {
		return --count;
	}
}
