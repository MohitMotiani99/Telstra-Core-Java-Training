package pack1;

import java.util.ArrayList;
import java.util.function.Consumer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		MathOperations add = (int a,int b)->(a+b);
		System.out.println(add.operation(10,30));
		
		MathOperations sub = (a,b)->(a-b);
		System.out.println(sub.operation(5,4));
		
		MathOperations mult =(a,b)->(a*b);
		System.out.println(mult.operation(2,3));
		
		
		Circle c1 = new Circle("Blue",12.5) {
			
			@Override
			public String paint() {
				return "Circle drawn with colour "+colour+" and "+radius;
			}
			
		};
		System.out.println(c1.paint());
		
		System.out.println(new CircleInterface() {
			
			@Override
			public String circum() {
				// TODO Auto-generated method stub
				return "Circle Circumferenced";
			}
		});
		
		//********************************************************
		//Anonymous interfaces
		FormatString fs1 = (s)->"Hello"+s;
		FormatString fs2 = (s)->"Welcome"+s;
		
		System.out.println(fs1.formatstr("Amex"));
		System.out.println(fs2.formatstr("Bob"));
		//*****************************************************************
		
		
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		
		numbers.add(5);
		numbers.add(15);
		numbers.add(20);
		
		numbers.forEach((n)->{
			System.out.println(n);
		});
		
		Consumer<Integer> func = (n)->{
			System.out.println(n);
		};
		
		numbers.forEach(func);
		
		
		int sum=0;
		numbers.forEach((n)->{
			sum+=n;
		});
		System.out.println(sum);
		//*****************************************************************
		// Anonymous Class instances
	}
	
	public static int operate(int a,int b,MathOperations mop) {
		return mop.operation(a,b);
	}
	
	
	
	
	
		
}
