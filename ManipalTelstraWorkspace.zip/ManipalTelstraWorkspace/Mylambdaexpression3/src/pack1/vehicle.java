package pack1;

public interface vehicle {
	default interface 
}
