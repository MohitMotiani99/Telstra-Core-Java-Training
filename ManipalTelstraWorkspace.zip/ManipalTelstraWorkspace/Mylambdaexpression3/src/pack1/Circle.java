package pack1;

public abstract class Circle {
	String colour;
	double radius;
	public Circle(String colour, double radius) {
		super();
		this.colour = colour;
		this.radius = radius;
	}
	
	public abstract String paint();
}
