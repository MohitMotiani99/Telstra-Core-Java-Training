package pack1;

public interface MathOperations {
	int operation(int a,int b);
}
