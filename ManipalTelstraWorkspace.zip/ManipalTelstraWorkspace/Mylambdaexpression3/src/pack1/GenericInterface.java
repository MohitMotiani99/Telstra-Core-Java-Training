package pack1;

public interface GenericInterface<X extends Number>{
	X process(X arg1,X arg2);
}
