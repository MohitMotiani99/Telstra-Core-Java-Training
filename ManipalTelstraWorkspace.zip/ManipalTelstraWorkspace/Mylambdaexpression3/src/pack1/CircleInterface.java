package pack1;

public interface CircleInterface {
	String circum();
}
