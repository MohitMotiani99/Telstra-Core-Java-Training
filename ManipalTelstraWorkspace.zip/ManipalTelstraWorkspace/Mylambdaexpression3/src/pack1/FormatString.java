package pack1;

public interface FormatString {
	String formatstr(String s);
}
