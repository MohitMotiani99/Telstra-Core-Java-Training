package com.telstra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.ListIterator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		LinkedList<String> l1 = new LinkedList<String>();
		
		l1.add("orange");
		l1.add("red");
		l1.add("blue");
		System.out.println(l1.isEmpty());
		System.out.println(l1.contains("blue"));
		
		ListIterator<String> it = l1.listIterator(l1.size());
		
				
		//fwd
//		while(it.hasNext())
//			System.out.println(it.next()+" ");
//		System.out.println();
		
		//bwd
//		while(it.hasPrevious())
//			System.out.println(it.previous());
//		System.out.println();
//	
		
		
		ArrayList<String> a1 = new ArrayList<String>();
		
		ListIterator<String> it1 = a1.listIterator();
		
		Collections.reverse(l1);
		System.out.println(l1);
		Collections.shuffle(l1);
		System.out.println(l1);
	}

}
