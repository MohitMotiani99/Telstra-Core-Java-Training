package com.telstra;

import java.util.LinkedList;
import java.util.Queue;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Queue<String> q = new LinkedList<String>();
		
		q.add("Java");
		q.add("JS");
		q.add("HTML");
		
		System.out.println(q.poll());
		System.out.println(q.peek());
		
	}

}
