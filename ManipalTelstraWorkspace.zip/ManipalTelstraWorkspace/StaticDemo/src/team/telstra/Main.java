package team.telstra;

public class Main {

	public static void main(String[] args) {
		
		Person person1 = new Person("Mohit",21);
		System.out.println(person1);
		
		Person person2 = new Person("Neha",22);
		System.out.println(person2);
		
		Person person3 = new Person("Navneet",21);
		System.out.println(person3);
		
		System.out.println(Person.getCount());
	}

}
