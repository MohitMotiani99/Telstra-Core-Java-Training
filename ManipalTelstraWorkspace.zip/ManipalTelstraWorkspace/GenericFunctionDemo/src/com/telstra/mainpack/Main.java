package com.telstra.mainpack;

import com.telstra.pack1.Product;
import com.telstra.pack1.Test;

public class Main {

	public static void main(String[] args) {
		
		Integer[] intarr = {3,5,7,9};
		Test.printArray(intarr);
		System.out.println();
		
		Product[] parr = {new Product(1, "lol"),new Product(2,"yo")};
		
		Test.printArray(parr);
		System.out.println();
		String sarr[] = {"Amex","Lamex","1"};
		
		Test.printArray(sarr);
	}

}
