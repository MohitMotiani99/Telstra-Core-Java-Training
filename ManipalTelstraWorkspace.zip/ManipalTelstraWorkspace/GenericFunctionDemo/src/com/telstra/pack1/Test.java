package com.telstra.pack1;

public class Test {
	
	public static <T> void printArray(T[] alist) {
		for(T ele:alist) {
			System.out.print(ele+"   ");
		}
	}
	
}
