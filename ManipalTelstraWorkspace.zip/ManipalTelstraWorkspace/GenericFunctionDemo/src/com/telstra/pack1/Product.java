package com.telstra.pack1;

public class Product {
	private int id;
	private String name;
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + "]";
	}
	public Product(int id, String string) {
		super();
		this.id = id;
		this.name = string;
	}
	
	
}
