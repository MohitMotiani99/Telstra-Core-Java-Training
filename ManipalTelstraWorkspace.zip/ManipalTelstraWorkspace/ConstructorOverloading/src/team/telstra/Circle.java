package team.telstra;

public class Circle {
	
	private double radius;
	private String color;
	public Circle(double radius, String color) {
		super();
		this.radius = radius;
		this.color = color;
	}
	public Circle(String color,double radius) {
		super();
		this.radius = radius;
		this.color = color;
	}
	public Circle() {
		this(3.5,"Blue");
		//this is a call for a fully parameterized constructor
	}
	public Circle(String color) {
		this(6.5,color);
	}
	public Circle(double radius) {
		this(radius,"Brown");
	}
	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", color=" + color + "]";
	}
	
}
