package com.telstra;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

// Online IDE - Code Editor, Compiler, Interpreter

public class abc2
{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a= in.nextInt();
        int[] p = new int[a];
        int[] q = new int[a];
        
        Map<Integer,Integer> m = new LinkedHashMap<Integer,Integer>();
        
        for(int i=0;i<a;i+=2){
            p[i]=in.nextInt();
            p[i+1]=in.nextInt();
            
            if(m.containsKey(p[i]))
            m.put(p[i],Math.max(m.get(p[i]),p[i+1]));
            else
            m.put(p[i],p[i+1]);
            
            
        }
        for(int i=0;i<a;i+=2){
            q[i]=in.nextInt();
            q[i+1]=in.nextInt();
            
            if(m.containsKey(q[i]))
            m.put(q[i],Math.max(m.get(q[i]),q[i+1]));
            else
            m.put(q[i],q[i+1]);
        }
//        for(int i=0;i<a;i++) {
//        	if(i%2==0) {
//        		if(m.containsKey(p[i]))
//        			m.put(p[i], Math.max(m.get(p[i]), p[i+1]));
//        		else
//        			m.put(p[i], p[i+1]);
//        	}
//        	
//        }
//        for(int i=0;i<a;i++) {
//        	if(i%2==0) {
//        		if(m.containsKey(q[i]))
//        			m.put(q[i], Math.max(m.get(q[i]), q[i+1]));
//         		else
//        			m.put(q[i], q[i+1]);
//        	}
//        	
//        }
        System.out.println(m);
        for(Integer i:m.keySet()){
            System.out.println(i);
            System.out.println(m.get(i));
        }
        
        in.close();
    }
}
