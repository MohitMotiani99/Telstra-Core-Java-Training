package com.telstra;

import java.util.Scanner;



public class Main {

	public static void main(String[] args) {
		// Command line argument is strings
		
		Scanner sc=new Scanner(System.in);
		
		int len=Integer.parseInt(args[0]);
		
		System.out.println(args[1]);
		
		int [] arr=new int[len];
		
		// Summing the elements of an array
		
		System.out.println("Enter the element in the array");
		
		int sum=0;
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
			sum+=arr[i];
		}
		
		System.out.println("Sum is : "+sum);
		
		int min=MinimumArray(arr);
		System.out.println("Minimim Element: "+min);
		
		int max=MaximumArray(arr);
		System.out.println("Maximum Element :"+max);
		
		sc.close();
	}
	
	public static int MinimumArray(int[] arr1) {
		int min=arr1[0];
		
		for(int i=1;i<arr1.length;i++) {
			if(min>arr1[i])
				min=arr1[i];
		}
		
		return min;
	}
	
	public static int MaximumArray(int[] arr1) {
		
		int max=arr1[0];
		
		for(int i=1;i<arr1.length;i++) {
			max=(max<arr1[i])?arr1[i]:max;
		}
		
		return max;
	}
}
