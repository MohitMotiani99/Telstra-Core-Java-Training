package com.telstra.pack1;

public interface MyFunction {
	public int apply(int n1,int n2);
}
