package com.telstra.pack1;

import java.util.function.Predicate;

public class Class2 implements Predicate<Object>{

	@Override
	public boolean test(Object t) {
		// TODO Auto-generated method stub
		if((Integer)t<18)
			return true;
		return false;
	}
	
}
