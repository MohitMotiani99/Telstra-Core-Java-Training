package com.telstra.pack1;

import java.util.function.Function;

public class Class1 implements Function<Integer, Long>{

	@Override
	public Long apply(Integer t) {
		
		Long res = t+15L;
		
		System.out.println(res);
		
		return null;
	}

}
