package com.telstra.pack1;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		MyFunction myfunction = (n1,n2)->{return (n1+n2);};
		int res = myfunction.apply(10,30);
		System.out.println(res);
		
		Function<Integer, Long> f1 = new Class1();
		System.out.println(f1.apply(5));
		
		Function<Integer, Long> f2 = (n)->(long)n+3L;
		System.out.println(f2.apply(15));
		
		Predicate<Object> fp = new Class2();
		System.out.println((fp.test(13)));
		
		
		Predicate<Double> fp2 = (d)->d<100;
		Predicate<Double> fp3 = (d)->d>=75;
		
		Scanner sc = new Scanner(System.in);
//		System.out.println("Enter %");
//		double per = sc.nextDouble();
//		if(fp2.and(fp3).test(per))
//			System.out.println("Passed Top");
//		else
//			System.out.println("Not Passed Top");
//		
		System.out.println(fp2.and(fp3).negate().test(66D));
		
		Predicate<Integer> fp4 =(n)->n>10; 
		//System.out.println(Predicate<Integer>{(n)->n>);
		System.out.println(fp4.test(12));
		
		Predicate<Reversenum> pfrevnum = (revnum)->revnum.getN()==revnum.getRevnum();
		System.out.println("**********"+pfrevnum.test(new Reversenum(12321)));
		
		
		
		StringBuilder sb = new StringBuilder("racecar");
		
		Predicate<StringBuilder> fppal = (str)->sb==sb.reverse();
		System.out.println("Pallindrome? "+fppal.test(sb));
		
		Predicate<String> pf5 =(st)->st.contains("a");
		Predicate<String> pf6 = (st)->st.equalsIgnoreCase("Admin");
		
		System.out.println(pf5.or(pf6).test("Apple"));
		
		
		//1
		ArrayList<User> ulist = new ArrayList<User>();
		ulist.add(new User(31,"amex","hr"));
		ulist.add(new User(22,"bobcat","admin"));
		ulist.add(new User(3,"catcat","admin"));
		
		Predicate<User> fpuser = (u)->u.getRole().equalsIgnoreCase("ADMIN");
		for(User u:ulist) {
			if(fpuser.test(u))
				System.out.println(u);
		}
		
		System.out.println(getAdmins(ulist, fpuser));
		
		ulist.forEach((u)->{
			if(fpuser.test(u))
				System.out.println(u);
		});
		
		Predicate<User> fpuser_2 = (u)->u.getId()>=20 && u.getId()<=40;
		
		ulist.forEach((u)->{
			if(fpuser_2.test(u))
				System.out.println(u);
		});
		
		Function<Integer,Integer> multiply = (value)->value*2;
		Function<Integer,Integer> add = (value)->value+2;
		
		// when called like this compose fun will first call add then multiply
		Function<Integer,Integer> addThenMultiply = multiply.compose(add);
		
		System.out.println(addThenMultiply.apply(5));
		
		System.out.println(add.andThen(multiply).apply(5));
		
		
		
		UnaryOperator<Integer> xor1 = (a)->a^1;
		System.out.println(xor1.apply(3));
		
		
		Predicate<Integer> fp7 =(i)->i>10;
		System.out.println(isGreater(15,fp7));
		
		
		
		sc.close();
	}
	
	public static boolean isGreater(int n,Predicate<Integer> p) {
		if(p.test(n))
			return true;
		return false;
	}
	
	public static ArrayList<User> getAdmins(ArrayList<User> ulist,Predicate<User> p){
		ArrayList<User> res = new ArrayList<User>();
		for(User u : ulist) {
			if(p.test(u))
				res.add(u);
		}
		return res;
	}
}
