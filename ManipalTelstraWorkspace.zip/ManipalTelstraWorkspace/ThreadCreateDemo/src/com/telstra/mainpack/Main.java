package com.telstra.mainpack;

import com.telstra.threadpack.ThreadClass1;
import com.telstra.threadpack.ThreadClass2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadClass1 tob1 = new ThreadClass1();
		
		//Thread by default is NORM_PRIORITY
		Thread t1 = new Thread(tob1);
		t1.setPriority(10);
		t1.setName("Thread1");
		
		t1.start();
		
		//System.out.println(t1.isAlive());
		
		Thread t2 = new Thread(tob1);
		t2.setName("Thread2");
		
		t2.start();
		
//		try {
//			t2.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		Thread t3 = new Thread(tob1);
		//System.out.println(t3.isAlive());
		t3.setName("Thread3");
		
		t3.start();
		
		
//		try {
//			t2.join();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		//t2.yield();
		
		System.out.println("Last Print");
		
//		ThreadClass2 t3 = new ThreadClass2();
//		t3.setName("Thread3");
//		t3.start();
//		
//		ThreadClass2 t4 = new ThreadClass2();
//		t4.setName("Thread4");
//		t4.start();
	}

}
