package com.telstra;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int res=0;
		
		try {
		
		int n1=Integer.parseInt(args[0]);
		int n2=Integer.parseInt(args[1]);
		
		res=n1/n2;
		
		}catch(ArithmeticException e1) {
			System.out.println("Division by 0 "+e1.getMessage());
			e1.printStackTrace();
		}
		catch(NumberFormatException e2) {
			System.out.println("Invalid Inputs "+e2.getMessage());
			e2.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException e3) {
			System.out.println("Insufficient Data "+e3.getMessage());
			e3.printStackTrace();
		}
		finally {
			System.out.println("In finally block");
			System.out.println(res);
		}
		
		System.out.println("End");
		
		// no args given : ArrayOutOfBoundsException
		// no numeric string given :NumbeerFormatException
		// div by 0 : ArithematiException
	}

}
