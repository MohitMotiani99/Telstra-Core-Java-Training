package com.telstra.fpack;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.telstra.data.Student;

public class FileWriteClass {
	private String createRec(Student s) {
		return s.getSId()+":"+s.getSName();
	}
	
	public void writeRec(int id,String name) {
		Student s=new Student(id,name);
		
		String str=createRec(s);
		
		//default is rewrite mode : false
		// open in append mode
		try(FileWriter out = new FileWriter("C:\\Users\\d976640\\Desktop\\Stdfile.txt",true);
				BufferedWriter bw = new BufferedWriter(out);){
			
			bw.write(str);
			bw.newLine();
			
			System.out.println("Record Added success");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
