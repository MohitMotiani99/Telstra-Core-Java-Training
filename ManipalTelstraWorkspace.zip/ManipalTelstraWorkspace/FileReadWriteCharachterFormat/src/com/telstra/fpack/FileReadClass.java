package com.telstra.fpack;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.telstra.data.Student;

public class FileReadClass {
	
	public Student[] readFile() {
		
		Student[] stdarr = new Student[5];

		
		try(FileReader fr = new FileReader("C:\\Users\\d976640\\Desktop\\Stdfile.txt");
				BufferedReader br = new BufferedReader(fr);) {
			
			String str="";
			int i=0;
			while((str=br.readLine())!=null) {
				System.out.println(str);
				String[] sword = str.split(":");
				int id=Integer.parseInt(sword[0]);
				String name = sword[1];
				
				Student s= new Student(id,name);
				stdarr[i++]=s;
				
				System.out.println(s);
			}			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return stdarr;

		
	}
	
}
