package com.telstra.mainpack;

import java.util.Scanner;

import com.telstra.data.Student;
import com.telstra.fpack.FileReadClass;
import com.telstra.fpack.FileWriteClass;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.println("Enter student id");
//		int id=sc.nextInt();
//		System.out.println("Enter stiudent name");
//		String name=sc.next();
//		
//		FileWriteClass fw = new FileWriteClass();
//		
//		fw.writeRec(id, name);
//		
//		sc.close();
		
		FileReadClass fr=new FileReadClass();
		Student[] stdarr=fr.readFile();
		
		System.out.println("Printing....");
		for(Student s:stdarr) {
			if(s!=null)
				System.out.println(s);
		}
		
	}

}
