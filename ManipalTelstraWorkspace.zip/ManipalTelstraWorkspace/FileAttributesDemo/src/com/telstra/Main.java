package com.telstra;

import java.io.File;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// M1 to use a file
		File file1 = new File("C:\\Users\\d976640\\Desktop\\telstrafile1.txt");
		
		try {
			file1.createNewFile();
			System.out.println("File Created Successfully....");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println(file1.getAbsolutePath());
		System.out.println(file1.getName());
		System.out.println(file1.getParent());
		
		// M2 to use a file
		File file2 = new File("C:/Users/d976640/Desktop","telstrafile2.txt");
		try {
			file2.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// For a ddirec
		
		File dir = new File("C:\\ManipalTelstraWorkspace");
		File[] flist = dir.listFiles();
		
		for(File f:flist) {
			if(f.isDirectory())
				System.out.println(f.getName());
		}
		
	}

}
