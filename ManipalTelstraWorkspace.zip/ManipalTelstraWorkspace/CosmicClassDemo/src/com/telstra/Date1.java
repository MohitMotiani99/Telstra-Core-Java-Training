package com.telstra;

import java.util.Objects;

@SuppressWarnings("unused")
public class Date1 {
	
	private int dd,mm,yy;

	public Date1(int dd, int mm, int yy) {
		super();
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}

	@Override
	public String toString() {
		return "Date1 [dd=" + dd + ", mm=" + mm + ", yy=" + yy + "]";
	}

//	@Override
//	public int hashCode() {
//		return Objects.hash(dd, mm, yy);
//	}

//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Date1 other = (Date1) obj;
//		return dd == other.dd && mm == other.mm && yy == other.yy;
//	}
	
	public boolean equals(Object obj) {
		Date1 d=(Date1)obj;
		
		if(dd==d.dd && mm==d.mm && yy==d.yy)
			return true;
		return false;
	}
	
	public int hashCode() {
		return dd^mm^yy;
	}
	
	
}
