package com.telstra;

public class Main {

	public static void main(String[] args) {
		
		Date1 d1=new Date1(21,7,2021);
		Date1 d2=new Date1(21,7,2021);
		
		Date1 d3= d1;//copying the reference of d1 to d3
		
		System.out.println(d1.equals(d2));
		//comparing the reference or the address location
		// new creates new address
		// d3 not made by new so it has same address as d1
		
		
		System.out.println(d1.equals(d3));
		
		// == operator : always just only compares addresses/ references
		System.out.println(d1==d2);
		System.out.println(d1==d3);
		
		System.out.println(d1.hashCode()+" "+d2.hashCode()+" "+d3.hashCode());
	}

}
