package team.telstra.mainpack;

import team.telstra.mathpack.MathOperation;
import team.telstra.threadpack.AddThread;
import team.telstra.threadpack.SubThread;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MathOperation op1 = new MathOperation();
		// op1 {own value i} to conduct add & subtract
		
		AddThread t1 = new AddThread(op1, "thread1");
		
		
		SubThread t5 = new SubThread(op1, "thread5");
		SubThread t6 = new SubThread(op1, "thread6");
		SubThread t4 = new SubThread(op1, "thread4");

		
		//AddThread t2 = new AddThread(op1, "thread2");
		//AddThread t3 = new AddThread(op1, "thread3");
		
		
		
		
		
		
		
//		MathOperation op2 = new MathOperation();
//		// op1 {own value i} to conduct add & subtract
//		
//		MathOperation op3 = new MathOperation();
//		// op1 {own value i} to conduct add & subtract
		
		
	}

}
