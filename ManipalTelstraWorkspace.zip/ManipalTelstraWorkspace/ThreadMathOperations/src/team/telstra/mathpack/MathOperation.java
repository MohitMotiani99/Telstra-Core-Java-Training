package team.telstra.mathpack;

public class MathOperation{
	
	private int i=0;
	
	public synchronized void add(int num) {
		
		this.notify();// notify the thread waiting on this thaat wait is over
		i+=num;
		System.out.println("i value in add : "+i);
	}
	public synchronized void sub(int num) {
		if(i<=0)
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//object class method
		i-=num;
		System.out.println("i value in subtract : "+i);
	}
	
	
}
