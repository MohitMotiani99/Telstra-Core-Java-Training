package team.telstra.threadpack;

import team.telstra.mathpack.MathOperation;

public class SubThread implements Runnable {

	private MathOperation op;
	private Thread t;
	
	public SubThread(MathOperation op, String threadName) {
		super();
		this.op = op;
		this.t = new Thread(this);
		this.t.setName(threadName);
		this.t.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		op.sub(5);
	}

	
}
