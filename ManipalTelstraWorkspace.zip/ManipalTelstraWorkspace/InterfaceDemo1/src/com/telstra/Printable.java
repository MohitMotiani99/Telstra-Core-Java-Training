package com.telstra;

public interface Printable {
	
	void show();
	
}
