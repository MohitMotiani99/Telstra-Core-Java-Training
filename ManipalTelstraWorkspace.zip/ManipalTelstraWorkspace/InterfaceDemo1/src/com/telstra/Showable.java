package com.telstra;

public interface Showable {
	
	int count=100;
	
	void show();
	
}
