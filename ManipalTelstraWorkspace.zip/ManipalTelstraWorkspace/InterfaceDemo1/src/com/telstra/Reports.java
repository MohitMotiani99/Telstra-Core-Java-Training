package com.telstra;

public class Reports implements Printable,Showable {

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

//	@Override
//	public void show() {
//		System.out.println("Welcome to interface method");
//		System.out.println(count);
//	}

//	@Override
//	public void () {
//		System.out.println("Welcome");
//	}
	
	
	
}
