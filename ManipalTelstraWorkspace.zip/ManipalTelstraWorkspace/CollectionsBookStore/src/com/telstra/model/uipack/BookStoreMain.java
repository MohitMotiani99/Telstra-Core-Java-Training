package com.telstra.model.uipack;

import java.util.ArrayList;
import java.util.Scanner;

import com.telstra.model.bookops.BookOperationsImpl;
import com.telstra.model.ppack.Book;
import com.telstra.model.servicepack.BookServices;


@SuppressWarnings("unused")
public class BookStoreMain {

	public static void main(String[] args) {
		
		
		
		Scanner scanner = new Scanner(System.in);
        while(true){
            System.out.println("1. Add a Book");
            System.out.println("2. Get a Book");
            System.out.println("3. List of Books");
            System.out.println("4. Delete a Book");
            System.out.println("5. Update Book price");
            System.out.println("6. Get Inventory Value");
            System.out.println("7. Add to cart");
            System.out.println("8.  Get the bill");
            System.out.println("9. Biwe the cart");
            System.out.println("10. Delete from cart");
            System.out.println("11. Exit");
           
            System.out.println("Enter your choice");
            int choice = scanner.nextInt();
           
            switch(choice){
            case 1:
            {
                System.out.println("Enter the details of the Book");
                int bookId = scanner.nextInt();
                String bookName = scanner.next();
                int bookPrice = scanner.nextInt();
                int units = scanner.nextInt();
                
                System.out.println(BookServices.addService(bookId, bookName, bookPrice, units));
            	break;
            }
            case 2:
            {
            	System.out.println("Enter the Book ID of the Book");
                int bookId = scanner.nextInt();
                System.out.println(BookServices.getBookService(bookId));
            	break;
            }
            case 3:
            {
                ArrayList<Book> blist = BookServices.getAllBooksService();
                for(Book book:blist)
                	System.out.println(book);
            	break;
            }
            case 4:
            {
            	System.out.println("Enter the Book ID of the Book");
                int bookId = scanner.nextInt();
                System.out.println(BookServices.getDeleteService(bookId));
            	break;
            }
            case 5:
            {
            	System.out.println("Enter the Book ID of the Book");
                int bookId = scanner.nextInt();
                System.out.println("Enter the Book Updated Price");
                int updPrice = scanner.nextInt();
                System.out.println(BookServices.getUpdateBookServices(bookId, updPrice));
            	break;
            }
            case 6:
            {
            	System.out.println(BookServices.getIneventoryValueService());
            	break;
            }
            default:
                scanner.close();
                System.out.println("Bye");
                System.exit(0);
            }

	    }
        
    }
}
