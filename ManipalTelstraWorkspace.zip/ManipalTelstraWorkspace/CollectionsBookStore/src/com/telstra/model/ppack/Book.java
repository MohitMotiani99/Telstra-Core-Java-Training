package com.telstra.model.ppack;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@ToString
public class Book {
	
	private int bookId;
	private String bookName;
	@Setter private int bookPrice;
	private int units;
	
	
}
