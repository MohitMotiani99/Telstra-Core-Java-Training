package com.telstra.model.ppack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import com.telstra.model.bookops.BookOperationsImpl;

public class Customer {
	
	private static int count = 1;
	
	private final int tid;
	private ArrayList<Book> slist = new ArrayList<Book>(); 
	private HashMap<Integer,Integer> smap = new HashMap<Integer, Integer>();
	public Customer() {
		super();
		this.tid = count++;
	}
	public void addToCart(int bid,int noOfUnits) {
		
		BookOperationsImpl bop = new BookOperationsImpl();
		Book book = bop.getABook(bid);
		slist.add(book);
		smap.put(book.getBookId(),book.getBookPrice()*noOfUnits);//check if noOfUnits available
	}
	
	public long getBill() {
		
		Collection<Integer> value = smap.values();
		Iterator<Integer> itr1 = value.iterator();
		
		int amount = 0;
		
		while(itr1.hasNext()) {
			amount+=itr1.next();
		}
		return amount;
	}
}
