package com.telstra.model.bookops;

import java.util.ArrayList;
import java.util.HashMap;

import com.telstra.model.ppack.Book;

public class BookOperationsImpl implements BookOperations{

	private ArrayList<Book> blist = new ArrayList<Book>();
	
	// key : bookid
	// value : bookPrice*units
	HashMap<Integer, Integer> bmap = new HashMap<Integer, Integer>();
	
	@Override
	public String addBook(Book book) {
		
		blist.add(book);
		bmap.put(book.getBookId(), book.getBookPrice()*book.getUnits());
		return "Book Added Successfully";
	}

	@Override
	public Book getABook(int bookId) {
		
		for(Book book:blist) {
			if(book.getBookId()==bookId)
				return book;
		}
		
		return null;
	}

	@Override
	public ArrayList<Book> getAllBooks() {
		return blist;
	}

	@Override
	public String deleteBook(int bookId) {
		Book book = getABook(bookId);
		if(book != null) {
			blist.remove(book);
			bmap.remove(bookId);
			return "Book Deleted Successfully";
		}
		return "Book not founf for deletion";
	}

	@Override
	public long getInverntoryValue() {
		
		long totalamt = 0;
		for(int bid:bmap.keySet())
			totalamt+=bmap.get(bid);
		
		return totalamt;
	}

	@Override
	public String updateBook(int bookId, int updPrice) {
		
		Book book = getABook(bookId);
		if(book != null) {
			book.setBookPrice(updPrice);
			bmap.put(book.getBookId(), book.getBookPrice()*book.getUnits());
			return "Book Price Updated Successfully";
		}
		
		return "Book not found";
	}
	
	
	
}
