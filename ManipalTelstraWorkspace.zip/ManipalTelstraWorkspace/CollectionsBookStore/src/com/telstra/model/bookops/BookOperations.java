package com.telstra.model.bookops;

import java.util.ArrayList;

import com.telstra.model.ppack.Book;

public interface BookOperations {
	
	String addBook(Book book);
	Book getABook(int bookId);
	ArrayList<Book> getAllBooks();
	String deleteBook(int bookId);
	String updateBook(int bookId,int updPrice);
	long getInverntoryValue();
	
}
