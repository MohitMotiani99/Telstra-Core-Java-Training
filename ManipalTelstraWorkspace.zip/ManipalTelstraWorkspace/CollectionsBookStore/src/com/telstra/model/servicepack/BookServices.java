package com.telstra.model.servicepack;

import java.util.ArrayList;

import com.telstra.model.bookops.BookOperationsImpl;
import com.telstra.model.ppack.Book;

public class BookServices {
	
	static BookOperationsImpl bop = new BookOperationsImpl();
	
	public static String addService(int bookId,String bookName,int bookPrice,int units) {
		Book book = new Book(bookId,bookName,bookPrice,units);
		return bop.addBook(book);
	}
	public static String getBookService(int bookId) {
		Book book = bop.getABook(bookId);
		if(book != null)
        	return book.toString();
        else
        	return "Book Not Found";
	}
	public static ArrayList<Book> getAllBooksService() {
		return bop.getAllBooks();
	}
	public static long getIneventoryValueService() {
		return bop.getInverntoryValue();
	}
	public static String getDeleteService(int bookId) {
		return bop.deleteBook(bookId);
	}
	public static String getUpdateBookServices(int bookId,int updPrice) {
		return bop.updateBook(bookId, updPrice);
	}
}
