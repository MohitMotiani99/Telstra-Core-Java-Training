package com.telstra.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.telstra.model.Student;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Writing the serialized object into the file
		try (FileOutputStream output = new FileOutputStream("C:\\Users\\d976640\\Desktop\\std.dat",true);
				ObjectOutputStream out = new ObjectOutputStream(output);
			FileInputStream input=new FileInputStream("C:\\Users\\d976640\\Desktop\\std.dat");
				ObjectInputStream in = new ObjectInputStream(input);){
			
			Student sob1= new Student(1,"Dax",222);
			out.writeObject(sob1);
			
			Student sob2= new Student(2,"Hax",333);
			out.writeObject(sob2);
			
			Student sob3= new Student(3,"Shax",444);
			out.writeObject(sob3);
			
			System.out.println("Records Written");

			
			//1. Deserialize the object
			// 	we are not constructing the object back,no constructors will be work
			//  we are just getting our data back
			
			// 2. Read the object
			
			
			while(input.available()>0) {
				Student student = (Student)in.readObject();
				
				System.out.println(student);
			}
			
			
			
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
