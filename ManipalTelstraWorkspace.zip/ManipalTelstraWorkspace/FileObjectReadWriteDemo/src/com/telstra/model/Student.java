package com.telstra.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@ToString
public class Student implements Serializable{
	
	/**
	 * 
	 */
	// This interface means the instances of class student are permanantly persisted
	// This interface has no method
	private static final long serialVersionUID = 3759677691404972723L;
	private int sId;
	private String sName;
	private int sAge;
	
	
}
