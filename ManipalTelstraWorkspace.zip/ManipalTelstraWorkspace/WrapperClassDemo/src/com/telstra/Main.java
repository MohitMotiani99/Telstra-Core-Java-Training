package com.telstra;

public class Main {
	
	public static void main(String[] args) {
		
		Integer iob1=new Integer(10);
		System.out.println(iob1);
		
		Integer obi2=20;
		System.out.println(obi2);
		
		Integer obi3=new Integer("15");
		System.out.println(obi3);
		
		// Unboxing
		
		int ui1=iob1;
		
		// Auto boxing
		
		Integer io4=44;
		
		//  string to int
		
		System.out.println(Integer.parseInt("23"));
		
		// integer to string
		System.out.println(Integer.toString(ui1));
		System.out.println(Integer.toString(io4));
		
		
	}
	
}
