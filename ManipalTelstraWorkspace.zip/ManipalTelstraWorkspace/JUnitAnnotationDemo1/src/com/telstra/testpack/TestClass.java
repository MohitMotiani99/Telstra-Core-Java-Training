package com.telstra.testpack;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestClass {

	//will work before every test case starts
	// can have any number of before
	@Before
	public void before() {
		System.out.println("Works before test case");
	}
	
	@BeforeClass
	public static void beforeClass() {
		System.out.println("Works once before all test case");
	}
	
	@After
	public void after() {
		System.out.println("Works after test case");
	}
	
	@AfterClass
	public static void afterClass() {
		System.out.println("Works once after all test case");
	}
	
	@Test
	public void test1() {
		System.out.println("In test1");
	}
	
	@Test
	public void test2() {
		System.out.println("In test2");
	}
}
