package com.telstra;

import java.util.ArrayList;
import java.util.Collections;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Student> slist = new ArrayList<Student>();
		slist.add(new Student(1,"x",15));
		slist.add(new Student(1,"x",10));
		slist.add(new Student(1,"x",20));
		
		System.out.println(slist);
		Collections.sort(slist);
		System.out.println(slist);
		
		
	}

}
