package com.telstra;

import java.util.Scanner;

public class MainLibrary {

	public static void main(String[] args) {
		
		// To improve the code : Use Scanner class sc
		
		Scanner sc=new Scanner(System.in);
		
//		int bookId=sc.nextInt();
//		String bookName=sc.nextLine();
//		int bookPrice=sc.nextInt();
		
		
		// Menu driven program
		//psvm ---> UI
		
		//Book book1=new Book(bookId,bookName,bookPrice);
		Book book1 =new Book(3,"Java",300);
		
		System.out.println(book1);
		System.out.println(book1.getBookName()+"    "+ book1.getBookPrice());
		System.out.println(book1.toString());
		System.out.println(book1.hashCode());
		
		System.out.println("Enter no. of books");
		int len=sc.nextInt();
		Book[] bookarr=new Book[len];
		
		for(int i=0;i<bookarr.length;i++) {
			System.out.println("Enter Book Id,Bookname,Bookprice");
			int bookId=sc.nextInt();
			String bookName=sc.next();
			int bookPrice=sc.nextInt();
			
			bookarr[i]= new Book(bookId,bookName,bookPrice);
			
			System.out.println(bookarr[i]);
		}
		
		sc.close();
		
		// Enhanced for loop
		
		for(Book b:bookarr)
			System.out.println(b);
		
		
	}

}
