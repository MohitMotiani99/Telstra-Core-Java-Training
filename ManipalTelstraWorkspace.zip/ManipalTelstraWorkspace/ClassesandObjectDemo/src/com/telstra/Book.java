package com.telstra;

import java.util.Objects;

public class Book {
	
	// instance or member variables
	
	// each object/instance will be given the copy of these members to store its state
	// NO access specifiers : default : these variables and methods can be accessed within package
	
	private int bookId;
	private String bookName;
	private int bookPrice;
	
	// java provides a special function constructor to create instances
	// same name as the class
	// to give initial state of the instance
	// generally public ,private in singleton class
	// they do no return any value
	
	public Book(int bookId, String bookName, int bookPrice) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookPrice = bookPrice;
	}

	public int getBookId() {
		return bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public int getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}

	// from parent class ---> Object Class it is the root class for all classes in java
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookPrice=" + bookPrice + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(bookId, bookName, bookPrice);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return bookId == other.bookId && Objects.equals(bookName, other.bookName) && bookPrice == other.bookPrice;
	}
	
	

}
