package com.telstra;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set s = new HashSet();
		s.add(1);
		s.add("aaa");
		s.add(12.5);
		s.add(null); //  mull is alowed
		
		System.out.println(s);
		
		HashSet<String> s1 = new HashSet<String>();
		s1.add("zzz");
		s1.add("xxx");
		s1.add("mmm");
		
		System.out.println(s1);
		
		Set<String> s2 = new LinkedHashSet<String>();
		s2.add("apple");
		s2.add("zuck");
		s2.add("toms");
		
		System.out.println(s2);
		
		Set<String> s3 = new TreeSet<String>();
		s3.add("zero");
		s3.add("one");
		s3.add("two");
		s3.add("eight");
		
		System.out.println(s3);
		
		
		
		
		Set<Person> s4 = new LinkedHashSet<Person>();
		s4.add(new Person(10,22));
		s4.add(new Person(11,23));
		s4.add(new Person(12,24));
		
		System.out.println(s4);
		
	}

}
