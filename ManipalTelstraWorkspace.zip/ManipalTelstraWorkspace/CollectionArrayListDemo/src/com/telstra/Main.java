package com.telstra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		List<String> strarr = new ArrayList<String>();
//		
//		strarr.add("Meera");
//		strarr.add("Mary");
//		strarr.add("Arjun");
//		strarr.add("Mary");
//		
//		
//		System.out.println(strarr);
//		strarr.add(1,"Mahesh");
//		System.out.println(strarr);
//		strarr.remove(3);
//		System.out.println(strarr);
//		strarr.add(3,"mariam");
//		System.out.println(strarr);
//		strarr.remove("mariam");
//		System.out.println(strarr);
//		
//		
//		ArrayList<String> subarr = new ArrayList<String>();
//		subarr.add("One");
//		subarr.add("Two");
//		
//		strarr.addAll(1,subarr);
//		System.out.println(strarr);
//		
//		System.out.println(strarr.get(2));
//		
//		
//		for(String str:strarr) {
//			System.out.print(str+" ");
//		}
//		System.out.println();
//		
//		Iterator<String> it = strarr.iterator();
//		while(it.hasNext()) {
//			System.out.print(it.next().toUpperCase()+" ");
//		}
//		System.out.println();
//		
		// find sum 
		
		Scanner sc = new Scanner(System.in);
//		int n=sc.nextInt();
//		ArrayList<Integer> ilist = new ArrayList<Integer>(n);
//		
//		System.out.println(ilist.size());
//		
//		for(int i=0;i<n;i++) {
//			int ele = sc.nextInt();
//			ilist.add(ele);
//		}
//		
//		Iterator<Integer> it1 = ilist.iterator();
//		
//		int sum=0;
//		while(it1.hasNext()) {
//			sum+=it1.next();
//		}
//		System.out.println(sum);
		
		
//		Collections.sort(strarr);
//		System.out.println(strarr);
//		
		
		ArrayList<Person> plist = new ArrayList<Person>();
		plist.add(new Person(1,22));
		plist.add(new Person(2,44));
		plist.add(new Person(3,66));
		
		for(Person p : plist) {
			if(p.getId()==2)
				System.out.println(p);
		}
		
		sc.close();
	}

}
