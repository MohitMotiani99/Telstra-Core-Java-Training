package com.telstra;

import java.util.Stack;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// stack i schild of vector not array list
		
		Stack<String> st = new Stack<String>();
		
		st.push("Do");
		st.push("you");
		st.push("remember?");
		
		System.out.println(st);
		System.out.println(st.pop());
		System.out.println(st.peek());
		
		while(!st.isEmpty())
			System.out.println(st.pop());
		
		st.add("hey");
		System.out.println(st);
		
		//System.out.println(5.22+6.5F);
		
		System.out.println(st.search("Do"));
	}
	

}
