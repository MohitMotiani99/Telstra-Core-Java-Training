package com.telstra.emppack;

public class Employee {
	// private only visible access inside class
	// No access specifiers mentioned default:package friendly
	// protected package friendly plus for derived class in diff package
	// public accessible everywhere
	protected int empId;
	protected String empName;
	protected int bSal;
	public Employee(int empId, String empName, int bSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.bSal = bSal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", bSal=" + bSal + "]";
	}
	
	public String getDetails() {
		return empId+" "+empName+" "+bSal;
	}
	
}
