package com.telstra.emppack;

public class Manager extends Employee{
	
	private String deptname;
	private int empCount;
	
	public Manager(int empId, String empName, int bSal, String deptname, int empCount) {
		super(empId, empName, bSal); //Constructor Chaining
		this.deptname = deptname;
		this.empCount = empCount;
	}
	
	public String getDetails() {
		return super.getDetails()+" "+deptname+"  "+empCount;
	}

	public String getDeptname() {
		return deptname;
	}

	public int getEmpCount() {
		return empCount;
	}
	
	
}
