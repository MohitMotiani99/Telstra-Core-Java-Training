package com.telstra.taxpack;

import com.telstra.emppack.*;
@SuppressWarnings("unused")

public class Tax {
	public static double calctax(Employee e) {
		if(e instanceof Manager) {
			Manager m=(Manager)e;
			return 15000.0;
		}
		else if(e instanceof Programmer) {
			Programmer p=(Programmer)e;
			return 12000.0;
		}
		else {
			return 10000.0;
		}
	}
}
