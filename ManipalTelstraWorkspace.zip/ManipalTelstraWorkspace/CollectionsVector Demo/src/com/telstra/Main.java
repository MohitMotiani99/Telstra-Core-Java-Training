package com.telstra;

import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//duplicate ele yes
		//thread safe yes
		
		//similar to arraylist
		
		Vector<String> v = new Vector<String>();
		
		v.add("lac");
		v.add("larry");
		v.add("lambert");
		v.add("lulkoil");
		
		//no iterator
		Enumeration<String> e = v.elements();
		System.out.println(v);
		
		//check enum for others
		//List<String> l = new List<String>() 
		//check iterator for vector also
		
		
		while(e.hasMoreElements()) {
			System.out.print(e.nextElement()+" ");
		}
	}

}
