package team.telstra;

public class BYPLMain {

	public static void main(String[] args) {
		
		Consumer consumer = new Consumer(100,3000,2);
		System.out.println(consumer);
		
	}

}
