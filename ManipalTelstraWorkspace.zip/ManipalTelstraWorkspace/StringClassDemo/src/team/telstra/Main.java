package team.telstra;

import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1 = "Java World";
		String str2 = "Java World";
		String str3 = new String("Java World");
		
		// strings are stored in string pool,if 2 have same content then stored one time unless new reference not made
		
		System.out.println(str1==str2);
		System.out.println(str1==str3);
		
		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(str3));
		System.out.println(str1.equalsIgnoreCase("java wOrld"));
		
		String str10="Welcome";
		
		System.out.println(str10.charAt(0));
		System.out.println(str10.length());
		System.out.println(str10.toLowerCase());
		System.out.println(str10);
		System.out.println(str10.toCharArray());
		System.out.println(str10.toUpperCase());
		
		String str11=str10.toLowerCase();
		System.out.println(str11);
		
		System.out.println(str10.substring(1, 4));
		System.out.println(str10.indexOf("W"));
		System.out.println(str10.replace('e', 'i'));
		System.out.println(str10.replaceAll("Wel", "Hell"));
		
		int i=10;
		String istr=String.valueOf(i);
		System.out.println(istr);
		
		String str13 = "Welcome:all:to:java:world";
		
		String[] words =str13.split(":");
		for(String s:words)
			System.out.print(s+" ");
		
		System.out.println();
		
		StringTokenizer st = new StringTokenizer("http://10.133.45.55//56",":");
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
		
		String str15="Java";
		System.out.println(str15.hashCode());
		str15+=" Programming";// this is ok
		System.out.println(str15.hashCode());
	}

}
