package pack1;

public class Person {
	private int pId;
	private int age;
	private String email;
	private String gender;
	private String city;
	public Person(int pId, int age, String email, String gender, String city) {
		super();
		this.pId = pId;
		this.age = age;
		this.email = email;
		this.gender = gender;
		this.city = city;
	}
	public int getpId() {
		return pId;
	}
	public int getAge() {
		return age;
	}
	public String getEmail() {
		return email;
	}
	public String getGender() {
		return gender;
	}
	public String getCity() {
		return city;
	}
	
	
}
