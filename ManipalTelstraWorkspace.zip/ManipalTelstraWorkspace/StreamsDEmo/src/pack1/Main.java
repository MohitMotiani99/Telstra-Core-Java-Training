package pack1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Main {
	public static void main(String[] args) {
		
		List<Integer> numbers = Arrays.asList(4,3,2,5);
		
		// map operation thru streams
		// squaring each ele in the collection
		
		List<Integer> sqnumbers = numbers.stream()
										  .map(x->x*x)
										  .collect(Collectors.toList());
		
		System.out.println(sqnumbers);
		
		//filter
		List<String> slist =Arrays.asList("Amex","Bob","Dat","Dad");
		List<String> rlist = slist.stream().filter(s->s.startsWith("D"))
							      .collect(Collectors.toList());
		
		System.out.println(rlist);
		
		//sort
		
		List<String> sortlist = slist.stream().sorted().collect(Collectors.toList());
		System.out.println(sortlist);
		
		
		List<Integer> numbers1 = Arrays.asList(1,2,3,4,5,3,4);
		Set<Integer> sqnumbersset = numbers1.stream().map(x->x*x).collect(Collectors.toSet());
		
		System.out.println(sqnumbersset);
		
		//forEach
		
		numbers1.stream().forEach(x->System.out.println(x));
		
		
		//reduce
		
		int sum=numbers1.stream().filter(x->x%2==0).reduce(0, (ans,i)->ans+i);
		System.out.println(sum);
		
		List<Person> plist = new ArrayList<Person>();
		
		plist.add(new Person(50,16,"Peter","peter@gmail.com","Female"));
		plist.add(new Person(60,23,"Peter","jeter@gmail.com","Male"));
		plist.add(new Person(70,21,"Peter","yeter@gmail.com","Male"));
		plist.add(new Person(80,25,"Peter","reter@gmail.com","Female"));
		
		
		boolean areAllMale = plist.stream().allMatch(p->p.getGender().equals("Male"));
		System.out.println("Are all males? "+areAllMale);
		
		boolean anyWomen = plist.stream().anyMatch(p->p.getGender().equals("Female"));
		System.out.println("Any female? "+anyWomen);
		
		boolean anyTeens = plist.stream().anyMatch(p->p.getAge()<20);
		System.out.println("Any teens? "+anyTeens);
		
		boolean nomatch = plist.stream().noneMatch(p->p.getEmail().endsWith("yahoo.com"));
		System.out.println("None yahoos? "+nomatch);
		
		
//		Set<String> sortedmails = plist.stream().map(p->p.getEmail())
//										.collect(Collectors.toCollection(TreeSet));
//		System.out.println(sortedmails);
//		
		
		List<String> names = Arrays.asList("xxx","","yyy","","abcde");
		
		long count = names.stream().filter(str->str.isEmpty()).count();
		System.out.println(count);
		
		
		
		
		Random rand = new Random();
		rand.ints().limit(10).sorted().forEach(System.out::println);
		
		
		
		// statistical
		
		IntSummaryStatistics stats = numbers.stream().mapToInt((x)->x).summaryStatistics();
		
		System.out.println("Higest number in list is : "+stats.getMax());
		System.out.println("Lowest number in list is: "+stats.getMin());
	}
}
