package com.telstra.emppack;

import com.telstra.exceptionpack.InsufficientLeaveException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee employee=new Employee(1000,12);
		
		try {
			System.out.println(employee.applyLeave(20));
		} catch (InsufficientLeaveException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
	}

}
