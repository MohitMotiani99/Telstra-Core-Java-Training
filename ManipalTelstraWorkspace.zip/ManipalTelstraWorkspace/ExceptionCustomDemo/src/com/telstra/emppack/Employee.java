package com.telstra.emppack;

import com.telstra.exceptionpack.InsufficientLeaveException;

public class Employee {

	private int empId;
	private int balanceLeave;
	public Employee(int empId, int balanceLeave) {
		super();
		this.empId = empId;
		this.balanceLeave = balanceLeave;
	}
	
	public String applyLeave(int appliedLeave) throws InsufficientLeaveException {
		if(balanceLeave<appliedLeave)
			throw new InsufficientLeaveException("Leave not sanctioned");
		else
		{
			balanceLeave-=appliedLeave;
			return "Leave Sanctioned";
		}
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", balanceLeave=" + balanceLeave + "]";
	}
	
	
}
