package mainpack;

import java.util.ArrayList;
import java.util.Collections;

import comparatorspack.AgeComparator;
import comparatorspack.NameComparartor;
import ppack.Person;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Person> plist = new ArrayList<Person>();
		plist.add(new Person(10,"Lac",31));
		plist.add(new Person(10,"Lambert",40));
		plist.add(new Person(10,"Larry",12));
		
		Collections.sort(plist,new AgeComparator());
		
		System.out.println(plist);
		
		Collections.sort(plist,new NameComparartor());
		
		System.out.println(plist);
		
	}

}
