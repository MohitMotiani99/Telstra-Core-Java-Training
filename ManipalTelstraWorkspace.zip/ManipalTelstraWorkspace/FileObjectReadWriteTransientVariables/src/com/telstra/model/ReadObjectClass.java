package com.telstra.model;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ReadObjectClass {
	
	public void readObject() {
		try (FileOutputStream output = new FileOutputStream("C:\\Users\\d976640\\Desktop\\std1.dat");
				ObjectOutputStream out = new ObjectOutputStream(output);){
			
			Student sob1= new Student(1,80,222);
			out.writeObject(sob1);
			
			Student sob2= new Student(2,50,333);
			out.writeObject(sob1);
			
			Student sob3= new Student(3,40,444);
			out.writeObject(sob1);
			
			System.out.println("Records Written");

			
			//1. Deserialize the object
			// 	we are not constructing the object back,no constructors will be work
			//  we are just getting our data back
			
			// 2. Read the object
	
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

	}
}
