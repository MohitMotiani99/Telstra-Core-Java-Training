package com.telstra.model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.telstra.model.Student;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Writing the serialized object into the file
		
}
