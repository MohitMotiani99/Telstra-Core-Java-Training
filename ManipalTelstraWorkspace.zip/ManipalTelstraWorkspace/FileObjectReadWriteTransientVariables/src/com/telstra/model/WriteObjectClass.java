package com.telstra.model;

public class WriteObjectClass {
	
}
