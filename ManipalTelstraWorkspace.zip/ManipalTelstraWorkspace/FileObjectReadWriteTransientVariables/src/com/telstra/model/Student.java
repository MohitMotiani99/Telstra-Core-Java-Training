package com.telstra.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
public class Student implements Serializable {
	
	 @Getter
	 @Setter
	 private int id;
	 @Getter
	 @Setter
	 private int m1;
	 @Getter
	 @Setter
	 private int m2;
	 @Getter
	 private transient int total;
	 
	 
	 
	 public void setTotal() {
		 total = m1+m2;
	 }



	public Student(int id, int m1, int m2) {
		super();
		this.id = id;
		this.m1 = m1;
		this.m2 = m2;
	}
	 
	 
}
