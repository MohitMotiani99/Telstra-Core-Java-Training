package com.telstra;

public class Main {

	public static void main(String[] args) {
		
		System.out.println(Summation.add("Hemant","Mohit"));
		System.out.println(Summation.add(4, 5000l, 4.666));
		System.out.println(Summation.add(5, 6));
		
		System.out.println(Average.average(10,10,20));
		System.out.println(Average.average(5,6,7,8,9));
		
		System.out.println(Average.average(6.77,5,6,7,8));
		
		System.out.println(Average.average(12, 10, 10,10));
		
	}

}
