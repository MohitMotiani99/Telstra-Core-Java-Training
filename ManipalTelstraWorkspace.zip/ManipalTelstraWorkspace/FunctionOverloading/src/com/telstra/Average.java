package com.telstra;

public class Average {
	public static double average(int ...numbers) {
		double sum =0 ;
		
		for(int n:numbers)
			sum+=n;
		
		return sum/numbers.length;
	}
	
	public static double average(double d,int ...numbers) {
		double sum=d;
		
		for(int n:numbers)
			sum+=n;
		
		return sum/numbers.length;
	}
	
	public static double average(double d,float f,int ...numbers) {
		double sum=d+f;
		
		for(int n:numbers)
			sum+=n;
		
		return sum/numbers.length;
	}
}
