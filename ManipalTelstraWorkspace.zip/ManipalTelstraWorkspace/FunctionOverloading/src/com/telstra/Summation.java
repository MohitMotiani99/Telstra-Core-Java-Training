package com.telstra;

public class Summation {
	public static int add(int x,int y) {
		return x+y;
	}
	
	public static double add(int x,long l,double d) {
		return x+l+d;
	}
	
	public static String add(String str1,String str2) {
		return str1+str2;
	}
}
