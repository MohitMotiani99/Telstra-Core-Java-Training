package com.pres.temporals;

import java.time.LocalTime;

public class LT {

	public static void main(String[] args) {
		
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("LOCAL TIME");
		System.out.println("**********************************************************");
		
		//hh-mm-ss-ns
		LocalTime lt = LocalTime.now();
		System.out.println("Current time is: "+lt);
		
		LocalTime lt2 = LocalTime.of(22,30,30);
		System.out.println("Time is: "+lt2);
		
		//y-m-d-h-min-s-ns
		System.out.println("Paremeters:");
		System.out.println("Time(with ns field): "+LocalTime.of(22, 45, 44, 30));
		System.out.println();
		System.out.println("Time Considered is :"+lt2);
		System.out.println("Hours(24h system) for the Time is: "+lt2.getHour());
		System.out.println("Minutes for the Time is: "+lt2.getMinute());
		System.out.println("Seconds for the Time is: "+lt2.getSecond());
		
		System.out.println();
		
		LocalTime lt3 = LocalTime.now();
		System.out.println("Current time is: "+lt3);
		System.out.println("Time after 5 seconds of current time :"+lt3.plusSeconds(5));
		System.out.println("Time after 5 minutes of current time :"+lt3.plusMinutes(5));
		System.out.println("Time after 5 hours of current time :"+lt3.plusHours(5));
		System.out.println();
		System.out.println("Time before 5 seconds of current time :"+lt3.minusSeconds(5));
		System.out.println("Time before 5 minutes of current time :"+lt3.minusMinutes(5));
		System.out.println("Time before 5 hours of current time :"+lt3.minusHours(5));
		System.out.println();
		
		// TemporalAdjusters Not available for only time object
		
		
		

	}

}
