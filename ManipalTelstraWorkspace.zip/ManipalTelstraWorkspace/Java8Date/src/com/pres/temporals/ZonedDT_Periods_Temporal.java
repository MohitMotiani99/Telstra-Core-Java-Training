package com.pres.temporals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.MonthDay;
import java.time.OffsetDateTime;
import java.time.Period;
import java.time.Year;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.util.Locale;

public class ZonedDT_Periods_Temporal {

	public static void main(String[] args) {
		
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("**********************************************************");
		
		ZoneId z1 = ZoneId.of("Asia/Kolkata");
		ZoneId z2 = ZoneId.of("Asia/Tokyo");
		
		System.out.println(z1);
		
		LocalTime lt1 = LocalTime.now(z1);
		System.out.println(lt1);
		LocalTime lt2 = LocalTime.now(z2);
		System.out.println(lt2);
		LocalDate ld2 = LocalDate.now(ZoneId.of("Europe/London"));
		System.out.println(ld2);
		LocalDateTime ly6 = LocalDateTime.now(ZoneId.of("America/Phoenix"));
		System.out.println(ly6);
		//---------------------------------------
		long hrs_d = ChronoUnit.HOURS.between(lt1, lt2);
		System.out.println(hrs_d);
		System.out.println(ChronoUnit.MINUTES.between(lt1, ly6));
		
		
		ZonedDateTime zdt = ZonedDateTime.now(z2);
		System.out.println("ZonedDateTime: "+zdt);
		System.out.println("Time difference: "+ChronoUnit.HOURS.between(ly6, zdt));
		
		Year y = Year.of(2022);
		System.out.println("Year set by of: "+y);
		System.out.println("Current year: "+Year.now());
		
		LocalDate ld4 = y.atDay(150);
		System.out.println("Date of the specified day provided: "+ld4);
		System.out.println("Month and year: "+y.atMonth(11));
		
		MonthDay md = MonthDay.now();
		
		System.out.println("Month and day at specified year: "+y.atMonthDay(md));
		
		Month m = Month.NOVEMBER;
		System.out.println("Month specified by enum month: "+m);
		System.out.println("Comparing with other month: "+m.compareTo(Month.NOVEMBER));
		System.out.println("Day of the first day of the month: "+m.firstDayOfYear(true));
		System.out.println("--------");
		Locale l =Locale.FRENCH;
		TextStyle ts = TextStyle.FULL;
		System.out.println("Print month in defined locale: "+m.getDisplayName(ts,l));
		
		
		System.out.println("count of the current month: "+m.getValue());
		
		System.out.println("--------------------------------------");
		
		YearMonth ym = YearMonth.now();
		System.out.println("YearMonth: "+ym);
		System.out.println("YearMonth set by of: "+YearMonth.of(2022, 12));
		System.out.println("Current Yearmonth: "+YearMonth.now(z2));
		
		
		System.out.println("Number of Days in the month: "+ym.lengthOfMonth());
		System.out.println("Number of days of the year: "+ym.lengthOfYear());
		System.out.println("Date format after setting the day for the yearmonth: "+ym.atDay(23));
		System.out.println("Modified Yearmonth before given number of months: "+ym.minusMonths(5));
		
		System.out.println("----------------------------------");
		Period p = Period.of(5,11,23);
		System.out.println("Number of days in the period: "+p.getDays());
		System.out.println("Number of years in the period: "+p.getYears());
		System.out.println("Number of months in the period: "+p.getMonths());
		System.out.println("Calender type: "+p.getChronology()); //Type of calender
		System.out.println("Substract the given number of months from the period"+p.minusMonths(10));
		System.out.println(p);
		
		System.out.println("--------------------------------------");
		
		Temporal tmp = p.addTo(LocalDate.now());
		System.out.println("Temporal: "+tmp);
		System.out.println(p.getUnits());
		
		
		ZoneOffset zof = ZoneOffset.MAX;
		OffsetDateTime osdt = OffsetDateTime.of(ly6, zof);
		System.out.println(ly6);
		System.out.println(osdt);
		
		System.out.println("-----------------------------------------------");
		
		LocalDate lDate = LocalDate.now();
		System.out.println(ChronoUnit.DAYS.between(LocalDate.of(1970, 1, 1),lDate));
		 int field = lDate.get(ChronoField.DAY_OF_MONTH);
		 System.out.println("Day of the month: "+field);
		 field = lDate.get(ChronoField.DAY_OF_WEEK);
		 System.out.println("Day of the month: "+field);
		 field = lDate.get(ChronoField.DAY_OF_YEAR);
		 System.out.println("Day of the year: "+field);
		 long epoch = lDate.getLong(ChronoField.EPOCH_DAY);//1970-1-1
		 System.out.println("No of Days from start: "+epoch);
		 field = lDate.get(ChronoField.ALIGNED_DAY_OF_WEEK_IN_MONTH);
		 System.out.println("Week in the month: "+field);
		 field = lDate.get(ChronoField.ALIGNED_DAY_OF_WEEK_IN_YEAR);
		 System.out.println("Day of the week in an year: "+field);
		 field = lDate.get(ChronoField.ERA);
		 System.out.println("Era: "+field);
	}

}