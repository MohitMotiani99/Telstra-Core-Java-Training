package com.pres.temporals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

@SuppressWarnings("unused")
public class LDT {

	public static void main(String[] args) {
		
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		System.out.println("LOCAL DATE TIME");
		System.out.println("**********************************************************");
		
		//y-m-d-h-min-s
		LocalDateTime ldt = LocalDateTime.of(2021,7,24,22,30,30);
		System.out.println("Date with Time is: "+ldt);
		
		//y-m-d-h-min-s-ns
		System.out.println("Date with time(with ns field): "+LocalDateTime.of(2022, 5, 18, 22, 45, 44, 30));
		System.out.println();
		
		
		System.out.println();
		// Combines LocalDate with time to give a LocalDateTime
		LocalDate ld = LocalDate.now();
		System.out.println("Date before adding time: "+ld);
		LocalDateTime ldt1 = ld.atTime(16,50,10);
		System.out.println("Date after adding time 16:50:10 is : "+ldt1);
		System.out.println();
		System.out.println("Date Considered: "+ldt1);
		//ChronoFields: Enums : display varios properties , not to edit
		//ChronoField
		System.out.println("The Day Number of the week is "+ldt1.getLong(ChronoField.DAY_OF_WEEK));
		System.out.println("The Day Number of the Month is "+ldt1.getLong(ChronoField.DAY_OF_MONTH));
		System.out.println("The Day Number of the year is "+ldt1.getLong(ChronoField.DAY_OF_YEAR));
		System.out.println("Number of Days from start(1970-1-1) is "+ldt1.getLong(ChronoField.EPOCH_DAY));
		System.out.println("The year is "+ldt1.getLong(ChronoField.YEAR));
		System.out.println("Clock Hour in 12h System of the time is: "+ldt1.getLong(ChronoField.CLOCK_HOUR_OF_AMPM));
		System.out.println("Clock Hour in 24h System of the time is: "+ldt1.getLong(ChronoField.CLOCK_HOUR_OF_DAY));
		//ALIGNED_DAY_OF_WEEK_IN_MONTH
		//ALIGNED_DAY_OF_WEEK_IN_YEAR
		//etc..
		
		
		System.out.println();
		System.out.println("Transforming Data Output according to our purpose");;
		System.out.println("Current Date Time Format :"+LocalDateTime.now());
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss");
		//remove vars that we dont want
		
		String ltd_pat = LocalDateTime.now().format(dtf);
		//displaying
		
		System.out.println("Converted Date Time: "+ltd_pat);;
		
		System.out.println("Reverting it Back..");
		LocalDateTime ly5 = LocalDateTime.parse(ltd_pat, dtf);
		System.out.println("Reverted Date Time: "+ly5);
		
		
		

	}

}
