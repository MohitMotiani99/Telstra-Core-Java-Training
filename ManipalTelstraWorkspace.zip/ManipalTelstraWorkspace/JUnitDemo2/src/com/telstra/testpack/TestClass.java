package com.telstra.testpack;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

//import org.junit.jupiter.api.Test;

import org.junit.Test;

import junit.framework.TestCase;

public class TestClass extends TestCase {
	
	@Test
	public void test() {
		
		int val1 =5 ;
		int val2 = 6;
		
//		assertTrue(val1<val2);
//		//expected and real values
//		assertFalse(val1<val2);
//		//ckecking logic not creating
		String str1 = new String("abc");
//		assertNull(str1);
//		// when 1 test case fails ,it does no check others
//		
		String str2 = "abc";
		//assertEquals(str1, str2);
		
		// will cheeck references
		//assertSame(str1, str2);
		
		//assertSame(str2, "abc");
		
		String[] earr= {"1","2","3"};
		String[] rarr= {"1","2","3"};
		
		//assertEquals(earr, rarr);
		assertArrayEquals(earr, rarr);
	}
	
}
