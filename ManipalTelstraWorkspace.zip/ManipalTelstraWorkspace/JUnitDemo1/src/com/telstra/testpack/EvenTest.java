package com.telstra.testpack;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.Test;

import com.telstra.pack1.EvenOddClass;

public class EvenTest {

	@Test
	public void test() {
	
		EvenOddClass pb = new EvenOddClass();
		assertEquals(true, pb.isEvenNumber(0));
		assertEquals(true, pb.isEvenNumber(11));
		assertEquals(true, pb.isEvenNumber(13));
	}
}
