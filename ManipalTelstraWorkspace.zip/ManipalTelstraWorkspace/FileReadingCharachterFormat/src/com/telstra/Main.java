package com.telstra;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileReader fr= new FileReader("C:\\Users\\d976640\\Desktop\\telstrafile1.txt");
				BufferedReader br = new BufferedReader(fr);){
			
			String str;
			
			//str=br.readLine();
			
			// not eof condition,used respective to data
			//while(!str.equalsIgnoreCase("END")) {
			// general
			while((str=br.readLine())!=null) {
				System.out.println(str);
				//str=br.readLine();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
