package dockerCalculator;

import java.util.Scanner;

public class Calc {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter 1st number: ");
		int a = in.nextInt();
		System.out.println("Enter 2nd Number: ");
		int b = in.nextInt();
//		int a= Integer.parseInt(args[0]);
//		int b= Integer.parseInt(args[1]);
		System.out.println("Enter choice");
		System.out.println("1.add");
		System.out.println("2.sub");
		System.out.println("3.mul");
		System.out.println("4.div");
		//in.nextLine();
		int ch = in.nextInt();         
		//int ch = Integer.parseInt(args[2]);
		
		switch (ch) {
		case 1:
			System.out.println(a+b);
			break;
		case 2:
			System.out.println(a-b);
			break;
		case 3:
			System.out.println(a*b);
			break;
		case 4:
			System.out.println(a/b);
			break;
		default:
			break;
		}

	}

}
