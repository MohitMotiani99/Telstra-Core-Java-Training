package com.telstra;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Hash Map");
		
		Map<Integer,String> hm = new HashMap<Integer, String>();
		hm.put(100, "lary");
		hm.put(200, "kary");
		hm.put(300, "mary");
		hm.put(100, "rary");
		hm.put(null, null);
		hm.put(400, "lulkoil");
		
		System.out.println(hm);
		
		System.out.println("Linked Hash Map");
		
		Map<Integer,String> lhm = new LinkedHashMap<Integer, String>();
		lhm.put(100, "lary");
		lhm.put(200, "kary");
		lhm.put(300, "mary");
		lhm.put(100, "rary");
		lhm.put(null, null);
		lhm.put(400, "lulkoil");
		
		System.out.println(lhm);
		
		System.out.println("Tree Map");
		
		Map<Integer,String> tm = new TreeMap<Integer, String>();
		tm.put(100, "lary");
		tm.put(200, "kary");
		tm.put(300, "mary");
		tm.put(100, "rary");
		//tm.put(null, null);// null key not allowed in keymap
		tm.put(400, "lulkoil");
		
		System.out.println(tm);
		
		System.out.println("Hashtable");
		//hashtable does not allow null a key or value
		//all its methods are thread safe,stack & vector also
		Hashtable<Integer, String> htb = new Hashtable<Integer, String>();
		htb.put(100, "lary");
		htb.put(200, "kary");
		htb.put(300, "mary");
		htb.put(100, "rary");
		//htb.put(250, null);// run time error
		htb.put(400, "lulkoil");
		
		System.out.println(htb);
		
		
		
	}

}



