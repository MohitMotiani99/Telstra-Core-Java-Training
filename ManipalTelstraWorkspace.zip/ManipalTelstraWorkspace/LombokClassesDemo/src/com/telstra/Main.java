package com.telstra;

public class Main {

	public static void main(String[] args) {
		
		Person p=new Person();
		p.setPId(100);
		p.setPName("Neha");
		p.setPAge(22);
		
		System.out.println(p);
		
		Customer cust1= new Customer(1,"Amex",5000);
		cust1.setCustId(4);
		System.out.println(cust1.getCustId());
		System.out.println(cust1);

	}

}
