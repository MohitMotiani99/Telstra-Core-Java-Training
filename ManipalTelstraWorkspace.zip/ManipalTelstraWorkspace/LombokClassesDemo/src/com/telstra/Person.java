package com.telstra;

import lombok.Data;

@SuppressWarnings("unused")
public @Data class Person {
	
	private int pId;
	private String pName;
	private int pAge;
	
}
