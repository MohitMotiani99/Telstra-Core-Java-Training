
package team.telstra;

import java.util.Scanner;

//import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		
		//Scanner class instance :Collection Framework in java
//		Scanner sc=new Scanner(System.in);
//		
//		System.out.println("Enter 3 numbers");
//		
//		int a=sc.nextInt();
//		double b=sc.nextDouble();
//		int c=sc.nextInt();
//		
//		// Stream class: Java IO classes
//		
//		// main(String [] args) command line arguments
//		
//		
////		int large1=(a>b)?a:b;
////		int large2=(large1>c)?large1:c;
//		
//		double large=(a>b)?(a>c)?a:c:(b>c)?b:c;
//		
//		System.out.println("Largest number: "+ large);
//		
//		sc.close();
		
		//Type conversion
		
		//1. Implicit Casting
		// On default literal are considered as double type
		float f1=13.33f; // 32 bit
		
		double d1=f1; // 64 bit
		
		System.out.println(d1);
		
		System.out.printf("%.2f", d1);
		System.out.println();
		//2. Explicit Conversion
		float f2=(float)d1;
		
		System.out.println(f2);
		
		
		
	}

}
