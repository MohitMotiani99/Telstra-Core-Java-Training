package com.telstra;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadInputConsole {
	
	public void readInput1() {
		
		InputStreamReader ir=null;
		BufferedReader br=null;
		
		String str1,str2;
		int res=0;
		
		// setup where its taking from , for both
		ir= new InputStreamReader(System.in);
		br = new BufferedReader(ir);
		
		try {
			System.out.println("Enter 1st Integer: ");
			str1 = br.readLine();
			System.out.println("Enter 2nd Integer: ");
			str2 = br.readLine();
			res=Integer.parseInt(str1)/Integer.parseInt(str2);
		} 
		catch(ArithmeticException e1) {
			System.out.println("Division by 0 "+e1.getMessage());
			e1.printStackTrace();
		}
		catch(NumberFormatException e2) {
			System.out.println("Invalid Inputs "+e2.getMessage());
			e2.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException e3) {
			System.out.println("Insufficient Data "+e3.getMessage());
			e3.printStackTrace();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				ir.close();
				br.close();
				System.out.println("Result: "+res);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				System.out.println("yo");
			}
		}
		//checked exception: needs to always handle
		
		
		
	}
	
	
	
	// WITH AUTOCLOSE
	public String readInput2() {
		//try with auto close option
		try(InputStreamReader ir= new InputStreamReader(System.in);
				BufferedReader br= new BufferedReader(ir); )
		{
			System.out.println("Enter 1st int: ");
			String str1=br.readLine();
			System.out.println("Enter 2nd int: ");
			String str2=br.readLine();
			
			int res=Integer.parseInt(str1)/Integer.parseInt(str2);
			
			return "Result: "+res;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return "Message: "+ e.getMessage();
		}
	}
	
	
	
	
	// WITH THROWS
	public int readInput3() throws IOException,NumberFormatException,ArithmeticException {
		InputStreamReader ir= new InputStreamReader(System.in);
		BufferedReader br= new BufferedReader(ir);
		
		System.out.println("Enter 1st int: ");
		String str1=br.readLine();
		System.out.println("Enter 2nd int: ");
		String str2=br.readLine();
		
		int res=Integer.parseInt(str1)/Integer.parseInt(str2);
		
		return res;
	}
	
}
