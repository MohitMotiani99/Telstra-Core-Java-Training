package com.telstra;

import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadInputConsole inp = new ReadInputConsole();
		
		//inp.readInput1();
		
		//System.out.println(inp.readInput2());
		
		try {
			System.out.println(inp.readInput3());
		} catch (NumberFormatException | ArithmeticException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
