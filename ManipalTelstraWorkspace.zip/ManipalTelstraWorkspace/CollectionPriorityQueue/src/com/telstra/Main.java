package com.telstra;

import java.util.PriorityQueue;
import java.util.Queue;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Item> pq= new PriorityQueue<Item>();
		pq.add(new Item(54,"Java"));
		pq.add(new Item(45,"C++"));
		pq.add(new Item(5,"C"));
		pq.add(new Item(154,"Javascript"));
		pq.add(new Item(60,"html"));
		
		
		System.out.println(pq);
		System.out.println(pq.poll());
		System.out.println(pq);
	}

}
